import type { GraphMemberDuty, GraphRunState } from "./scalars";

/**
 * Read-only discovery contracts. They carry no authority: publishing or reading a
 * catalogue entry never starts, resumes or authorizes a Run. Consumers that need
 * lifecycle control must obtain their own trusted admission.
 */
export const GRAPH_CATALOG_FORMAT = "omp.graph/catalog/v1" as const;
export const GRAPH_RUN_INDEX_FORMAT = "omp.graph/run-index/v1" as const;

/** A Run is reported stalled only after this much persisted inactivity, never by guesswork. */
export const GRAPH_DEFAULT_STALL_THRESHOLD_MS = 300_000;

/** `declared` means the author wrote `extensions.x-contract`; `derived` means the catalog inferred it. */
export type GraphCatalogContractSource = "declared" | "derived";

export interface GraphCatalogInput {
	name: string;
	description: string | null;
	media_type: string | null;
	required: boolean;
}

export interface GraphCatalogOutput extends GraphCatalogInput {
	node: string | null;
	output: string | null;
}

export interface GraphCatalogMember {
	key: string;
	duty: GraphMemberDuty;
	model: string;
}

export interface GraphCatalogEntry {
	graph_id: string;
	revision: string;
	digest: string;
	name: string;
	summary: string | null;
	contract_source: GraphCatalogContractSource;
	inputs: GraphCatalogInput[];
	outputs: GraphCatalogOutput[];
	report_events: string[];
	stall_threshold_ms: number | null;
	members: GraphCatalogMember[];
	nodes: number;
	/** Foreground local runner support only; a different host performs its own capability check. */
	local_run: { supported: boolean; reason: string | null };
}

export interface GraphCatalog {
	format: typeof GRAPH_CATALOG_FORMAT;
	entries: GraphCatalogEntry[];
}

/** Token and cost figures observed from Bot jobs; never a complete Run bill. */
export interface GraphObservedUsage {
	input_tokens: number | null;
	output_tokens: number | null;
	cache_read_tokens: number | null;
	cache_write_tokens: number | null;
	cost_usd: string | null;
	completeness: "complete" | "partial" | "unknown";
	measured_at: string | null;
	observed_sources?: number;
}

export interface GraphRunIndexEntry {
	run_id: string;
	graph_id: string;
	/** Frozen definition name; absent for Runs created before labels were recorded. */
	graph_name?: string;
	/** Caller-supplied task label from dispatch; never derived from Run content. */
	title?: string;
	state: GraphRunState;
	created_at: string;
	updated_at: string;
	/** Timestamp of the last persisted transition; not a live provider heartbeat. */
	last_activity_at: string;
	last_event: string | null;
	stalled: boolean;
	observed_bot_usage?: GraphObservedUsage;
}

export interface GraphRunIndex {
	format: typeof GRAPH_RUN_INDEX_FORMAT;
	as_of: string;
	stall_threshold_ms: number;
	runs: GraphRunIndexEntry[];
}
